#include<stdio.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<stdlib.h>
#include<math.h>
#include<errno.h>
int Semset(int sid, int semnum, int n);
int P(int sid,int semnum,int n);
int V(int sid,int semnum,int n);
int main()
{
   
    int pid;
    int semid;
    int val=3;
    key_t semkey;
    if((semkey=ftok("./reader.c",1))<0)
    {
        printf("ftok函数转换错误。\n");
        exit(1);
    }
    if((semid=semget(semkey,2,IPC_CREAT|IPC_EXCL|0700))<0)//创建信号灯集，其中包含2个信号灯
    {
        printf("semget函数创建信号灯集出现错误。\n");
        exit(2);
    }
    int ret;
    ret=semctl(semid,0,SETVAL,val);
    if(ret==-1)
    {
        perror("semctl 0:");
    }
    ret=semctl(semid,1,SETVAL,val);
   
    if(ret==-1)
    {
        perror("semctl 1");
    }
    P(semid,0,1);//对信号量集中的第0个信号量进行P操作
    P(semid,1,1);//对信号量集中的第1个信号量进行P操作

    if(pid=fork()<0)
    {
        printf("创建子进程错误。\n");
    }
   
    else
       
    if(pid>0)//父进程
    {
        int arg;
        arg=semctl(semid,0,GETVAL);
        printf("parent:sem0=%d\n",arg);
       
    }
    else//子进程
    {
        int arg;
        arg=semctl(semid,1,GETVAL);
        printf("child:sem1=%d\n",arg);  
    }
    semctl(semid,0,IPC_RMID);
}

int Semset(int sid,int semnum,int n)
{
    struct sembuf sm;
    sm.sem_num=semnum;
    sm.sem_op=n;
    sm.sem_flg=SEM_UNDO;
    if(semop(sid,&sm,1)==-1)
    {
        perror ("semop ");
        return 0;
    }
    return 1;
}

int P(int sid,int semnum,int n)
{
    return Semset(sid,semnum,-n);
}

int V(int sid,int semnum,int n)
{
    return Semset(sid,semnum,n);
}
