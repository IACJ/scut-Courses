#include <stdio.h>
 #include <pthread.h> /**/
 int sum=0;
void handle(void)
 {
 	int  i;
	 for( i=0; i < 100000; i++)
	 {
	 	//printf("my name is sub_thread. sum=%d\n",sum);
	 	sum++;
	 }
 }
 int main(void)
 {
	 pthread_t id;  /**/
	 int  i ;
	 int  ret;
	 ret = pthread_create(&id,NULL,(void *) handle,NULL);  /**/
	 if(ret != 0)
	 {
	 	printf ("Create pthread error!\n");
	 	return ;
	 }
	 for(i=0 ; i < 100000 ; i++)
	 {
	 	//printf("my name is main_thread.sum=%d\n",sum);
	 	sum++;
	 }
	 pthread_join(id,NULL); /**/
	 printf("sum=%d\n",sum);
	 return (0);
 }
